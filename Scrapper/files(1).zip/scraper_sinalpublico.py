"""
Scraper - Sinal Público
========================
Extrai todos os canais da página do Sinal Público.

Modos de uso:
  1. A partir de arquivo HTML salvo localmente:
       python scraper_sinalpublico.py --file pagina.html

  2. Direto da URL (requer requests + beautifulsoup4):
       python scraper_sinalpublico.py --url https://sinalpublicocanais.vercel.app/

Dependências:
  pip install beautifulsoup4 requests
"""

import re
import json
import argparse
from pathlib import Path

try:
    from bs4 import BeautifulSoup
except ImportError:
    raise ImportError("Instale o BeautifulSoup4:  pip install beautifulsoup4")


# ──────────────────────────────────────────────
# Funções principais
# ──────────────────────────────────────────────

def load_html_from_file(path: str) -> str:
    """Lê o HTML de um arquivo local."""
    return Path(path).read_text(encoding="utf-8")


def load_html_from_url(url: str) -> str:
    """Baixa o HTML de uma URL."""
    try:
        import requests
    except ImportError:
        raise ImportError("Instale requests:  pip install requests")

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        )
    }
    resp = requests.get(url, headers=headers, timeout=15)
    resp.raise_for_status()
    return resp.text


def parse_channels(html: str) -> list[dict]:
    """
    Extrai os canais do HTML.

    Cada canal retorna um dicionário com:
      - id     : identificador do canal  (ex: "globonews")
      - name   : nome legível            (ex: "Globo News")
      - url    : URL do player           (ex: "https://sinalpublicoetv.vercel.app/?id=globonews")
      - logo   : URL do logo PNG         (ex: "https://...globonews.png")
    """
    soup = BeautifulSoup(html, "html.parser")
    cards = soup.select(".channel-card")

    channels = []
    for card in cards:
        # URL do player (atributo data-url)
        player_url = card.get("data-url", "").strip()

        # ID do canal extraído da query string (?id=...)
        match = re.search(r"[?&]id=([^&]+)", player_url)
        channel_id = match.group(1) if match else ""

        # Logo: o HTML salvo usa data-savepage-src; online usa src normal
        img = card.find("img")
        logo = ""
        if img:
            logo = (
                img.get("data-savepage-src")  # arquivo salvo
                or img.get("src", "")         # online / sem extensão savepage
            )
            # Ignora src base64 embutido
            if logo.startswith("data:"):
                logo = img.get("data-savepage-src", "")

        # Nome do canal (texto dentro do card)
        name = " ".join(card.stripped_strings).strip()

        channels.append({
            "id":   channel_id,
            "name": name,
            "url":  player_url,
            "logo": logo,
        })

    return channels


# ──────────────────────────────────────────────
# Exportadores
# ──────────────────────────────────────────────

def export_json(channels: list[dict], output: str = "canais.json"):
    with open(output, "w", encoding="utf-8") as f:
        json.dump(channels, f, ensure_ascii=False, indent=2)
    print(f"[✓] JSON salvo em: {output}  ({len(channels)} canais)")


def export_csv(channels: list[dict], output: str = "canais.csv"):
    import csv
    with open(output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "name", "url", "logo"])
        writer.writeheader()
        writer.writerows(channels)
    print(f"[✓] CSV  salvo em: {output}  ({len(channels)} canais)")


def export_m3u(channels: list[dict], output: str = "canais.m3u"):
    """
    Gera uma playlist M3U apontando para os players do Sinal Público.
    Nota: as URLs são dos players web, não streams HLS diretos.
    """
    lines = ["#EXTM3U"]
    for ch in channels:
        logo_attr = f' tvg-logo="{ch["logo"]}"' if ch["logo"] else ""
        lines.append(f'#EXTINF:-1 tvg-id="{ch["id"]}"{logo_attr},{ch["name"]}')
        lines.append(ch["url"])
    Path(output).write_text("\n".join(lines), encoding="utf-8")
    print(f"[✓] M3U  salvo em: {output}  ({len(channels)} canais)")


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Scraper do Sinal Público — extrai lista de canais"
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--file", metavar="PATH",
                        help="Caminho para o arquivo HTML salvo localmente")
    source.add_argument("--url",  metavar="URL",
                        help="URL da página a ser baixada")

    parser.add_argument("--format", choices=["json", "csv", "m3u", "all"],
                        default="json",
                        help="Formato de saída (padrão: json)")
    parser.add_argument("--output", metavar="NOME_BASE", default="canais",
                        help="Nome base dos arquivos de saída (sem extensão)")
    args = parser.parse_args()

    # Carrega HTML
    if args.file:
        print(f"[~] Lendo arquivo: {args.file}")
        html = load_html_from_file(args.file)
    else:
        print(f"[~] Baixando: {args.url}")
        html = load_html_from_url(args.url)

    # Extrai canais
    channels = parse_channels(html)
    print(f"[✓] {len(channels)} canais encontrados")

    # Exporta
    fmt = args.format
    base = args.output
    if fmt in ("json", "all"):
        export_json(channels, f"{base}.json")
    if fmt in ("csv", "all"):
        export_csv(channels, f"{base}.csv")
    if fmt in ("m3u", "all"):
        export_m3u(channels, f"{base}.m3u")


if __name__ == "__main__":
    main()
